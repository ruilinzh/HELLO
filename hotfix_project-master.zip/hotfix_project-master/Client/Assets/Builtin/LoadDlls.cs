using HybridCLR;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

public class LoadDlls : MonoBehaviour
{
    [SerializeField] RectTransform Canvas;
    // Start is called before the first frame update
    void Start()
    {
        Addressables.InitializeAsync();
        LoadGameDll();

#if !UNITY_EDITOR
        var result = Addressables.LoadAssetAsync<TextAsset>("LoadHotfix.dll").WaitForCompletion();
        System.Reflection.Assembly.Load(result.bytes);
#endif
        GameObject prefab = Addressables.LoadAssetAsync<GameObject>("LoadHotfix").WaitForCompletion();
        GameObject go = GameObject.Instantiate<GameObject>(prefab);
        //go.transform.SetParent(this.Canvas);
        //go.transform.localPosition = Vector3.zero;
        //go.transform.localRotation = Quaternion.identity;
        //go.transform.localScale = Vector3.one;
        Addressables.Release(prefab);
    }


    void LoadGameDll()
    {
        //AsyncOperationHandle dn = Addressables.DownloadDependenciesAsync("AutoDlls", true);
        //dn.Completed += Dn_Completed;
        var ab = Addressables.LoadAssetsAsync<TextAsset>("AutoDlls" , null);
        ab.Completed += Dn_Completed;
    }

    private void Dn_Completed(AsyncOperationHandle<IList<TextAsset>> obj)
    {
        HomologousImageMode mode = HomologousImageMode.SuperSet;
        for (int i = 0; i < obj.Result.Count; i++)
        {
            LoadImageErrorCode err = RuntimeApi.LoadMetadataForAOTAssembly(obj.Result[i].bytes, mode);
            Debug.Log($"LoadMetadataForAOTAssembly:{obj.Result[i].name}. mode:{mode} ret:{err}");
        }
        Addressables.Release(obj.Result);
    }
}
