public class AOTGenericReferences : UnityEngine.MonoBehaviour
{

	// {{ constraint implement type
	// }} 

	// {{ AOT generic type
	//DG.Tweening.Core.DOGetter`1<System.Single>
	//DG.Tweening.Core.DOGetter`1<UnityEngine.Color>
	//DG.Tweening.Core.DOGetter`1<UnityEngine.Vector3>
	//DG.Tweening.Core.DOGetter`1<System.Object>
	//DG.Tweening.Core.DOGetter`1<UnityEngine.Quaternion>
	//DG.Tweening.Core.DOGetter`1<UnityEngine.Vector2>
	//DG.Tweening.Core.DOGetter`1<System.Int32>
	//DG.Tweening.Core.DOSetter`1<UnityEngine.Vector2>
	//DG.Tweening.Core.DOSetter`1<UnityEngine.Color>
	//DG.Tweening.Core.DOSetter`1<System.Int32>
	//DG.Tweening.Core.DOSetter`1<UnityEngine.Quaternion>
	//DG.Tweening.Core.DOSetter`1<UnityEngine.Vector3>
	//DG.Tweening.Core.DOSetter`1<System.Single>
	//DG.Tweening.Core.DOSetter`1<System.Object>
	//DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,System.Object,DG.Tweening.Plugins.Options.PathOptions>
	//DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.SpiralOptions>
	//DG.Tweening.Core.TweenerCore`3<UnityEngine.Quaternion,UnityEngine.Vector3,DG.Tweening.Plugins.Options.QuaternionOptions>
	//System.Action`1<System.Object>
	//System.Action`4<DG.Tweening.Plugins.Options.PathOptions,System.Object,UnityEngine.Quaternion,System.Object>
	//System.Collections.Generic.IEnumerator`1<System.Object>
	//System.Collections.Generic.List`1<System.Object>
	//System.Collections.Generic.List`1/Enumerator<System.Object>
	//System.Nullable`1<UnityEngine.Vector3>
	//UnityEngine.ResourceManagement.AsyncOperations.AsyncOperationHandle`1<System.Object>
	//UnityEngine.ResourceManagement.AsyncOperations.AsyncOperationHandle`1<System.Int64>
	// }}

	public void RefMethods()
	{
		// DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.Core.Extensions::Blendable<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions>(DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions>)
		// System.Object DG.Tweening.Core.Extensions::SetSpecialStartupMode<System.Object>(System.Object,DG.Tweening.Core.Enums.SpecialStartupMode)
		// DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.CircleOptions> DG.Tweening.DOTween::To<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.CircleOptions>(DG.Tweening.Plugins.Core.ABSTweenPlugin`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.CircleOptions>,DG.Tweening.Core.DOGetter`1<UnityEngine.Vector2>,DG.Tweening.Core.DOSetter`1<UnityEngine.Vector2>,UnityEngine.Vector2,System.Single)
		// DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,System.Object,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTween::To<UnityEngine.Vector3,System.Object,DG.Tweening.Plugins.Options.PathOptions>(DG.Tweening.Plugins.Core.ABSTweenPlugin`3<UnityEngine.Vector3,System.Object,DG.Tweening.Plugins.Options.PathOptions>,DG.Tweening.Core.DOGetter`1<UnityEngine.Vector3>,DG.Tweening.Core.DOSetter`1<UnityEngine.Vector3>,System.Object,System.Single)
		// DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.SpiralOptions> DG.Tweening.DOTween::To<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.SpiralOptions>(DG.Tweening.Plugins.Core.ABSTweenPlugin`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.SpiralOptions>,DG.Tweening.Core.DOGetter`1<UnityEngine.Vector3>,DG.Tweening.Core.DOSetter`1<UnityEngine.Vector3>,UnityEngine.Vector3,System.Single)
		// System.Object DG.Tweening.TweenExtensions::Pause<System.Object>(System.Object)
		// System.Object DG.Tweening.TweenExtensions::Play<System.Object>(System.Object)
		// System.Object DG.Tweening.TweenSettingsExtensions::From<System.Object>(System.Object,System.Boolean)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnComplete<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnKill<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnPlay<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnRewind<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnStart<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnStepComplete<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::OnUpdate<System.Object>(System.Object,DG.Tweening.TweenCallback)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetAutoKill<System.Object>(System.Object,System.Boolean)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetDelay<System.Object>(System.Object,System.Single)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetEase<System.Object>(System.Object,UnityEngine.AnimationCurve)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetEase<System.Object>(System.Object,DG.Tweening.Ease)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetId<System.Object>(System.Object,System.String)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetLoops<System.Object>(System.Object,System.Int32,DG.Tweening.LoopType)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetRelative<System.Object>(System.Object)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetRelative<System.Object>(System.Object,System.Boolean)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetSpeedBased<System.Object>(System.Object)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetTarget<System.Object>(System.Object,System.Object)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetUpdate<System.Object>(System.Object,System.Boolean)
		// System.Object DG.Tweening.TweenSettingsExtensions::SetUpdate<System.Object>(System.Object,DG.Tweening.UpdateType)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForKill>d__12>(System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter&,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForKill>d__12&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForRewind>d__11>(System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter&,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForRewind>d__11&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForCompletion>d__10>(System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter&,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForCompletion>d__10&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForElapsedLoops>d__13>(System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter&,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForElapsedLoops>d__13&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForPosition>d__14>(System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter&,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForPosition>d__14&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForStart>d__15>(System.Runtime.CompilerServices.YieldAwaitable/YieldAwaiter&,DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForStart>d__15&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForPosition>d__14>(DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForPosition>d__14&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForElapsedLoops>d__13>(DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForElapsedLoops>d__13&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForKill>d__12>(DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForKill>d__12&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForRewind>d__11>(DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForRewind>d__11&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForCompletion>d__10>(DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForCompletion>d__10&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForStart>d__15>(DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForStart>d__15&)
		// System.Object System.Threading.Interlocked::CompareExchange<System.Object>(System.Object&,System.Object,System.Object)
		// UnityEngine.ResourceManagement.AsyncOperations.AsyncOperationHandle`1<System.Object> UnityEngine.AddressableAssets.Addressables::LoadAssetAsync<System.Object>(System.Object)
		// System.Object UnityEngine.Component::GetComponent<System.Object>()
		// System.Object[] UnityEngine.Component::GetComponents<System.Object>()
		// System.Object UnityEngine.GameObject::AddComponent<System.Object>()
		// System.Object[] UnityEngine.GameObject::GetComponents<System.Object>()
		// System.Object UnityEngine.Object::Instantiate<System.Object>(System.Object)
	}
}