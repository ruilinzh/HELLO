using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;

public class Main : MonoBehaviour
{
    [SerializeField] GameObject Canvas;
    private void Awake()
    {
        DontDestroyOnLoad(this);
    }

    private void Start()
    {
        GameObject go = Addressables.LoadAssetAsync<GameObject>("UILoginPanel").WaitForCompletion();
        GameObject panel = GameObject.Instantiate<GameObject>(go);
        panel.transform.SetParent(this.Canvas.transform);
        panel.transform.localPosition = Vector3.zero;
        panel.transform.localScale = Vector3.one;
    }

}
