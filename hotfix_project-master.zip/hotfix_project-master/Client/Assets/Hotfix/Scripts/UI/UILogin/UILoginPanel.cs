using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UILoginPanel : MonoBehaviour
{
    [SerializeField] InputField acc;
    [SerializeField] InputField psw;
    [SerializeField] Button loginBtn;
    [SerializeField] Text tips;
    // Start is called before the first frame update
    void Start()
    {
        loginBtn.onClick.AddListener(this.OnClickLoginBtn);
    }

    private void OnClickLoginBtn()
    {
        tips.text = Time.deltaTime.ToString() + "        ����һ��image";
        var go = new GameObject("image");
        go.transform.SetParent(this.transform);
        go.transform.localPosition = Vector3.zero;
        go.transform.localScale = Vector3.one;
        go.AddComponent<Image>();
    }
}
