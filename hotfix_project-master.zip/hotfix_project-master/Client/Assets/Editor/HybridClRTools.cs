using HybridCLR.Editor;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;

public static class HybridClRTools
{
    [MenuItem("HybridCLR/Auto Copy Dlls")]
    public static void AutoCopyHybridCleDlls()
    {
        BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
        string fromDir = Path.Combine(HybridCLRSettings.Instance.strippedAOTDllOutputRootDir, target.ToString());
        string toDir = "Assets/Bundles/AotDlls";
        if (Directory.Exists(toDir))
        {
            Directory.Delete(toDir, true);
        }
        Directory.CreateDirectory(toDir);
        AssetDatabase.Refresh();
        AddressableAssetGroup group = AddressableAssetSettingsDefaultObject.Settings.FindGroup("AutoDlls");
        if (group == null)
        {
            group = HybridClRTools.CreateAssetGroup("AutoDlls");
        }
        foreach (string aotDll in HybridCLRSettings.Instance.patchAOTAssemblies)
        {
            string dllPath = Path.Combine(toDir, $"{aotDll}.bytes");
            File.Copy(Path.Combine(fromDir, aotDll), dllPath, true);
            AssetDatabase.Refresh();
            AssetImporter ai = AssetImporter.GetAtPath(dllPath);
            string guid = AssetDatabase.AssetPathToGUID(ai.assetPath);
            var entry = AddressableAssetSettingsDefaultObject.Settings.CreateOrMoveEntry(guid, group);
            entry.address = aotDll;
            entry.SetLabel("AutoDlls", true, true);
        }
        HybridClRTools.CopyHotfixDll();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        UnityEngine.Debug.Log("copy complete!");
    }


    static void CopyHotfixDll()
    {
        BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
        string fromDir = Path.Combine(HybridCLRSettings.Instance.hotUpdateDllCompileOutputRootDir, target.ToString());
        string toDir = "Assets/Bundles/AotDlls";
       
        foreach (var item in HybridCLRSettings.Instance.hotUpdateAssemblyDefinitions)
        {
            AddressableAssetGroup group = AddressableAssetSettingsDefaultObject.Settings.FindGroup(item.name);
            if (group == null)
            {
                group = HybridClRTools.CreateAssetGroup(item.name);
            }
            //UnityEngine.Debug.Log(item.name);
            string dllPath = Path.Combine(toDir, $"{item.name}.dll.bytes");
            File.Copy(Path.Combine(fromDir, $"{item.name}.dll"), dllPath, true);
            AssetDatabase.Refresh();
            AssetImporter ai = AssetImporter.GetAtPath(dllPath);
            string guid = AssetDatabase.AssetPathToGUID(ai.assetPath);
            var entry = AddressableAssetSettingsDefaultObject.Settings.CreateOrMoveEntry(guid, group);
            entry.address = $"{item.name}.dll";
        }
    }
    static AddressableAssetGroup CreateAssetGroup(string groupName)
    {
        var settings = AddressableAssetSettingsDefaultObject.Settings;
        return settings.CreateGroup(groupName, false, false, false,
            new List<AddressableAssetGroupSchema> { settings.DefaultGroup.Schemas[0], settings.DefaultGroup.Schemas[1] },
            typeof(SchemaType));
    }
    
}
