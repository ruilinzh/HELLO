using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.UI;

public class DownloadHotfix : MonoBehaviour
{
    [SerializeField] Text updateText;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(DoUpdateAddressadble(this.GameStart));
    }

    IEnumerator DoUpdateAddressadble(Action onDownloadComplete)
    {
        // Addressables ��ʼ��
        yield return Addressables.InitializeAsync();
        //������
        var checkHandle = Addressables.CheckForCatalogUpdates(false);
        yield return checkHandle;
        // �������Ƿ�ɹ�
        if (checkHandle.Status != AsyncOperationStatus.Succeeded)
        {
            //OnError("CheckForCatalogUpdates Error\n" + checkHandle.OperationException.ToString());
            yield break;
        }
        updateText.text = $"��Ҫ���ص���Դ�ļ�������:{checkHandle.Result.Count}";
        // ��⵽��Ҫ���µ�����
        if (checkHandle.Result.Count > 0)
        {
            var updateHandle = Addressables.UpdateCatalogs(checkHandle.Result, false);
            yield return updateHandle;

            if (updateHandle.Status != AsyncOperationStatus.Succeeded)
            {
                //OnError("UpdateCatalogs Error\n" + updateHandle.OperationException.ToString());
                yield break;
            }

            List<object> cusKeys = new List<object>();
            foreach (var item in updateHandle.Result)
            {
                cusKeys.AddRange(item.Keys);
            }
            // �����б�������
            List<IResourceLocator> locators = updateHandle.Result;
            foreach (var locator in locators)
            {
                // ��ȡ�����ص��ļ��ܴ�С
                var sizeHandle = Addressables.GetDownloadSizeAsync(locator.Keys);
                yield return sizeHandle;
                if (sizeHandle.Status != AsyncOperationStatus.Succeeded)
                {
                    //OnError("GetDownloadSizeAsync Error\n" + sizeHandle.OperationException.ToString());
                    yield break;
                }

                long totalDownloadSize = sizeHandle.Result;
                updateText.text = updateText.text + "\ndownload size : " + totalDownloadSize;
                Debug.Log("download size : " + totalDownloadSize);
                if (totalDownloadSize > 0)
                {
                    // ����
                    var downloadHandle = Addressables.DownloadDependenciesAsync(locator.Keys, Addressables.MergeMode.Union, false);
                    while (!downloadHandle.IsDone)
                    {
                        if (downloadHandle.Status == AsyncOperationStatus.Failed)
                        {
                            //OnError("DownloadDependenciesAsync Error\n" + downloadHandle.OperationException.ToString());
                            yield break;
                        }
                        // ���ؽ���
                        float percentage = downloadHandle.PercentComplete;
                        //bg.fillAmount = percentage;
                        Debug.Log($"������: {percentage}");
                        updateText.text = updateText.text + $"\n������: {percentage}";
                        yield return null;
                    }
                    if (downloadHandle.Status == AsyncOperationStatus.Succeeded)
                    {
                        Debug.Log("�������!");
                        updateText.text = updateText.text + "\n�������";
                        //loadPanel.SetActive(true);
                        //DownLoadPanel.SetActive(false);
                    }
                }
            }
        }
        else
        {
            updateText.text = updateText.text + "\nû�м�⵽����";
            yield return new WaitForSeconds(1f);
            //loadPanel.SetActive(true);
            //DownLoadPanel.SetActive(false);
        }

        onDownloadComplete();
    }

    void GameStart()
    {
        updateText.text = updateText.text + "\n   ��Ϸ��ʼ  22222";
#if !UNITY_EDITOR
        var result = Addressables.LoadAssetAsync<TextAsset>("Hotfix.dll").WaitForCompletion();
        System.Reflection.Assembly.Load(result.bytes);
#endif
        GameObject prefab = Addressables.LoadAssetAsync<GameObject>("Main").WaitForCompletion();
        GameObject gameStart = GameObject.Instantiate<GameObject>(prefab);

        Destroy(gameObject);

    }
}
